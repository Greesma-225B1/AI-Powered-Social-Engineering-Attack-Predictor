from flask import Flask, request
from twilio.twiml.messaging_response import MessagingResponse
import torch
from transformers import AutoTokenizer, AutoModelForSequenceClassification
import os

app = Flask(__name__)

# ==============================
# LOAD BERT MODEL (SAFE PATH)
# ==============================
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
MODEL_PATH = os.path.join(BASE_DIR, "..", "bert_model")

tokenizer = AutoTokenizer.from_pretrained(MODEL_PATH)
model = AutoModelForSequenceClassification.from_pretrained(MODEL_PATH)

device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
model.to(device)
model.eval()

print("✅ SMS BERT Model Loaded")

# ==============================
# SMS ENDPOINT
# ==============================
@app.route("/sms", methods=["POST"])
def sms_reply():
    # Handle Twilio + Postman formats
    incoming_msg = request.form.get('Body') or request.form.get('body') or ""

    print("📩 FULL REQUEST:", request.form)
    print("📩 MESSAGE RECEIVED:", incoming_msg)

    if not incoming_msg.strip():
        incoming_msg = "empty message"

    # ==============================
    # BERT PREDICTION
    # ==============================
    inputs = tokenizer(
        incoming_msg,
        return_tensors="pt",
        truncation=True,
        padding=True,
        max_length=128
    )

    inputs = {k: v.to(device) for k, v in inputs.items()}

    with torch.no_grad():
        outputs = model(**inputs)
        probs = torch.softmax(outputs.logits, dim=1)
        predicted_class = torch.argmax(probs, dim=1).item()

    # ==============================
    # LABEL MAPPING (EDIT IF NEEDED)
    # ==============================
    if predicted_class == 0:
        label = "🟢 Safe"
    elif predicted_class == 1:
        label = "🟡 Suspicious"
    else:
        label = "🔴 Attack"

    print(f"🤖 BERT Prediction: {label}")

    # ==============================
    # TWILIO RESPONSE
    # ==============================
    resp = MessagingResponse()
    resp.message(f"AI Result: {label}")

    return str(resp)


# ==============================
# RUN SERVER
# ==============================
if __name__ == "__main__":
    app.run(port=5001, debug=True)
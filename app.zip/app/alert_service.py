import smtplib
from email.mime.text import MIMEText

SENDER_EMAIL = "b9majorproject@gmail.com"
APP_PASSWORD = "tkgihldwubphcvev"  # same Gmail app password

def send_email_alert(message_text, confidence):

    subject = "🚨 HIGH RISK PHISHING DETECTED"
    body = f"""
    ALERT: A high-risk phishing email was detected.

    Confidence: {confidence:.2f}%

    Message:
    {message_text}
    """

    msg = MIMEText(body)
    msg["Subject"] = subject
    msg["From"] = SENDER_EMAIL
    msg["To"] = SENDER_EMAIL  # send to yourself

    with smtplib.SMTP_SSL("smtp.gmail.com", 465) as server:
        server.login(SENDER_EMAIL, APP_PASSWORD)
        server.send_message(msg)
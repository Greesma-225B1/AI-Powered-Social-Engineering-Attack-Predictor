from gmail_reader import fetch_unread_emails
from realtime_detector import process_message
import time

def gmail_monitor():
    print("📧 Gmail Monitor Started...")

    while True:
        emails = fetch_unread_emails()

        for mail in emails:
            print("New Email Detected")
            process_message(mail, source="Email")

        time.sleep(30)


if __name__ == "__main__":
    gmail_monitor()